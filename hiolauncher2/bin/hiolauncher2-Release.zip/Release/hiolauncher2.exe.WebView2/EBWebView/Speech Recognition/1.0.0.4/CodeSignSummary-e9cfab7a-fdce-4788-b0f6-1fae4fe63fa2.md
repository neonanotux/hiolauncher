 | FileName                  | Status | FileSize | TotalTime(sec) | Upload(sec) | Submit(sec) | SignWait(sec) | Retry Count | 
 |---------------------------|--------|----------|----------------|-------------|-------------|---------------|-------------|
 | eServices.Speech.core.dll | Pass   | 2.56MB   | 22.87          | 1.83        | 0.66        | 20.37         | 0           | 
